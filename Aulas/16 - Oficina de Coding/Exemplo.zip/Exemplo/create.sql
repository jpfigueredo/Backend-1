create table if not exists funcionarios (id int auto_increment primary key, nome varchar(255), sobrenome varchar(255),
cpf varchar(255), telefone varchar(255), cargo varchar(255), acesso bit);