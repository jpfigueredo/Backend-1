import java.util.Date;

public interface Vacinar {

    public void vacinarPessoa(String rg, Date dataVacina, String tipoVacina);
}
