public class FilmeNaoHabilitadoException extends Exception{
    public FilmeNaoHabilitadoException(String msg) {
        super(msg);
    }
}
