public class ManipuladorAceitar extends Manipulador {

    // --------------------------------------------------

    @Override
    public void verificar(Artigo arti)
    {
        System.out.println("Aceitado");
    }

}
