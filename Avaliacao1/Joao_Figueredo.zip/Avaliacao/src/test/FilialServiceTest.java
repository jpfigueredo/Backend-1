package test;

import dao.ConfiguracaoJDBC;
import dao.impl.FilialDaoImpl;
import model.Filial;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import service.FilialService;


public class FilialServiceTest {

    private FilialService filialService = new FilialService(new FilialDaoImpl(new ConfiguracaoJDBC()));

    @Test
    public void salvarFilial(){
        Filial filial1 = new Filial("Digital House", "São José", "12345678996", "Rio de Janeiro", "RJ", true);
        Filial filial2 = new Filial("Digital House", "São José", "12345678996", "Rio de Janeiro", "RJ", true);
        Filial filial3 = new Filial("Digital House", "São José", "12345678996", "Rio de Janeiro", "RJ", true);
        Filial filial4 = new Filial("Digital House", "São José", "12345678996", "Rio de Janeiro", "RJ", true);
        Filial filial5 = new Filial("Digital House", "São José", "12345678996", "Rio de Janeiro", "RJ", true);

        filialService.salvar(filial1);
        filialService.salvar(filial2);
        filialService.salvar(filial3);
        filialService.salvar(filial4);
        filialService.salvar(filial5);

        Assertions.assertTrue(filial1.getId() != null);
        Assertions.assertTrue(filial2.getId() != null);
        Assertions.assertTrue(filial3.getId() != null);
        Assertions.assertTrue(filial4.getId() != null);
        Assertions.assertTrue(filial5.getId() != null);
    }

}
