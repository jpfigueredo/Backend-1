package dao.impl;

import model.Filial;
import dao.*;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class FilialDaoImpl implements IDao<Filial> {

    private ConfiguracaoJDBC configuracaoJDBC;
    final static Logger log = Logger.getLogger(FilialDaoImpl.class);

    public FilialDaoImpl(ConfiguracaoJDBC configuracaoJDBC) {
        this.configuracaoJDBC = configuracaoJDBC;
    }

    @Override
    public Filial salvar(Filial filial) {
        log.debug("Salvando filial: " + filial.toString());

        Connection connection = configuracaoJDBC.conectarDB();
        Statement statement = null;
        String query = String.format("INSERT INTO FILIAL(nomeFilial,rua,numero,cidade,estado,ehCincoEstrelas)" +
                        "VALUES ('%s','%s','%s','%s','%s','%s')",
                filial.getNomeFilial(), filial.getRua(), filial.getNumero(),
                filial.getCidade(), filial.getEstado(), filial.getEhCincoEstrelas());
        try{
            statement = connection.createStatement();
            statement.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
            ResultSet resultSet = statement.getGeneratedKeys();
            if(resultSet.next()){
                filial.setId(resultSet.getInt(1));
            }

            connection.close();
        }catch (Exception e){
            e.printStackTrace();
        }


        return filial;
    }
}
